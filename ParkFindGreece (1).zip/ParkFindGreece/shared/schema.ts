import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const cities = pgTable("cities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  region: text("region").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  imageUrl: text("image_url"),
  totalParkingSpots: integer("total_parking_spots").default(0),
  availableSpots: integer("available_spots").default(0),
});

export const parkingLocations = pgTable("parking_locations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  cityId: varchar("city_id").references(() => cities.id).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  totalSpots: integer("total_spots").notNull(),
  availableSpots: integer("available_spots").notNull(),
  pricePerHour: decimal("price_per_hour", { precision: 5, scale: 2 }).notNull(),
  is24Hours: boolean("is_24_hours").default(false),
  isCovered: boolean("is_covered").default(false),
  hasSecurityGuard: boolean("has_security_guard").default(false),
  isAccessible: boolean("is_accessible").default(false),
  hasEVCharging: boolean("has_ev_charging").default(false),
  tags: text("tags").array(),
  distance: decimal("distance", { precision: 5, scale: 2 }).default("0"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userFavorites = pgTable("user_favorites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  parkingLocationId: varchar("parking_location_id").references(() => parkingLocations.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const parkingHistory = pgTable("parking_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  parkingLocationId: varchar("parking_location_id").references(() => parkingLocations.id).notNull(),
  visitedAt: timestamp("visited_at").defaultNow(),
});

export const parkingBookings = pgTable("parking_bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  parkingLocationId: varchar("parking_location_id").references(() => parkingLocations.id).notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  totalPrice: decimal("total_price", { precision: 6, scale: 2 }).notNull(),
  status: text("status").notNull().default("active"), // active, completed, cancelled
  paymentStatus: text("payment_status").notNull().default("pending"), // pending, paid, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const parkingReviews = pgTable("parking_reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  parkingLocationId: varchar("parking_location_id").references(() => parkingLocations.id).notNull(),
  rating: integer("rating").notNull(), // 1-5 stars
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const priceAlerts = pgTable("price_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  parkingLocationId: varchar("parking_location_id").references(() => parkingLocations.id).notNull(),
  maxPrice: decimal("max_price", { precision: 5, scale: 2 }).notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  type: text("type").notNull(), // price_alert, booking_reminder, availability_alert, etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  relatedId: varchar("related_id"), // parking location ID or booking ID
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  language: varchar("language").default("en"),
  notificationSettings: text("notification_settings").default("{}"), // JSON string
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCitySchema = createInsertSchema(cities).omit({
  id: true,
});

export const insertParkingLocationSchema = createInsertSchema(parkingLocations).omit({
  id: true,
  updatedAt: true,
});

export const insertUserFavoriteSchema = createInsertSchema(userFavorites).omit({
  id: true,
  createdAt: true,
});

export const insertParkingHistorySchema = createInsertSchema(parkingHistory).omit({
  id: true,
  visitedAt: true,
});

export const insertParkingBookingSchema = createInsertSchema(parkingBookings).omit({
  id: true,
  createdAt: true,
});

export const insertParkingReviewSchema = createInsertSchema(parkingReviews).omit({
  id: true,
  createdAt: true,
});

export const insertPriceAlertSchema = createInsertSchema(priceAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type City = typeof cities.$inferSelect;
export type ParkingLocation = typeof parkingLocations.$inferSelect;
export type UserFavorite = typeof userFavorites.$inferSelect;
export type ParkingHistory = typeof parkingHistory.$inferSelect;
export type ParkingBooking = typeof parkingBookings.$inferSelect;
export type ParkingReview = typeof parkingReviews.$inferSelect;
export type PriceAlert = typeof priceAlerts.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type User = typeof users.$inferSelect;

export type InsertCity = z.infer<typeof insertCitySchema>;
export type InsertParkingLocation = z.infer<typeof insertParkingLocationSchema>;
export type InsertUserFavorite = z.infer<typeof insertUserFavoriteSchema>;
export type InsertParkingHistory = z.infer<typeof insertParkingHistorySchema>;
export type InsertParkingBooking = z.infer<typeof insertParkingBookingSchema>;
export type InsertParkingReview = z.infer<typeof insertParkingReviewSchema>;
export type InsertPriceAlert = z.infer<typeof insertPriceAlertSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

import { AppHeader } from "@/components/app-header";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

export default function Profile() {
  return (
    <div className="bg-gray-50 font-inter min-h-screen">
      <AppHeader />
      <main className="max-w-md mx-auto bg-white min-h-screen">
        <div className="p-4">
          {/* Profile Header */}
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-greek-blue rounded-full mx-auto mb-4 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" 
                alt="User avatar" 
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="text-xl font-semibold text-gray-800">John Doe</h2>
            <p className="text-gray-600">john.doe@email.com</p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-greek-blue">47</div>
                <div className="text-xs text-gray-600">Visits</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-greek-blue">8</div>
                <div className="text-xs text-gray-600">Favorites</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-greek-blue">€142</div>
                <div className="text-xs text-gray-600">Saved</div>
              </CardContent>
            </Card>
          </div>

          {/* Settings */}
          <div className="space-y-4 mb-20">
            <h3 className="text-lg font-semibold text-gray-800">Settings</h3>
            
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-bell text-gray-600"></i>
                    <span className="text-gray-800">Push Notifications</span>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-map-marker-alt text-gray-600"></i>
                    <span className="text-gray-800">Location Services</span>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-moon text-gray-600"></i>
                    <span className="text-gray-800">Dark Mode</span>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 space-y-4">
                <Button variant="ghost" className="w-full justify-start">
                  <i className="fas fa-credit-card text-gray-600 mr-3"></i>
                  Payment Methods
                </Button>
                
                <Separator />
                
                <Button variant="ghost" className="w-full justify-start">
                  <i className="fas fa-question-circle text-gray-600 mr-3"></i>
                  Help & Support
                </Button>
                
                <Separator />
                
                <Button variant="ghost" className="w-full justify-start">
                  <i className="fas fa-info-circle text-gray-600 mr-3"></i>
                  About ParkGreece
                </Button>
                
                <Separator />
                
                <Button variant="ghost" className="w-full justify-start text-red-600">
                  <i className="fas fa-sign-out-alt mr-3"></i>
                  Sign Out
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppHeader } from "@/components/app-header";
import { BottomNavigation } from "@/components/bottom-navigation";
import { ParkingCard } from "@/components/parking-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { ParkingLocation } from "@shared/schema";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

  const { data: parkingLocations, isLoading } = useQuery<ParkingLocation[]>({
    queryKey: ["/api/parking-locations", searchQuery],
    enabled: searchQuery.length > 0,
  });

  const filters = [
    { id: "24h", label: "24/7", icon: "fas fa-clock" },
    { id: "covered", label: "Covered", icon: "fas fa-home" },
    { id: "accessible", label: "Accessible", icon: "fas fa-wheelchair" },
    { id: "security", label: "Security", icon: "fas fa-shield-alt" },
    { id: "ev", label: "EV Charging", icon: "fas fa-charging-station" },
  ];

  const toggleFilter = (filterId: string) => {
    setSelectedFilters(prev => 
      prev.includes(filterId) 
        ? prev.filter(id => id !== filterId)
        : [...prev, filterId]
    );
  };

  return (
    <div className="bg-gray-50 font-inter min-h-screen">
      <AppHeader />
      <main className="max-w-md mx-auto bg-white min-h-screen">
        <div className="p-4">
          <div className="relative mb-4">
            <i className="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            <Input
              type="text"
              placeholder="Search parking locations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:border-greek-blue focus:ring-2 focus:ring-greek-blue/20"
            />
          </div>

          <div className="flex flex-wrap gap-2 mb-6">
            {filters.map((filter) => (
              <Button
                key={filter.id}
                variant={selectedFilters.includes(filter.id) ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter(filter.id)}
                className={`flex items-center space-x-2 ${
                  selectedFilters.includes(filter.id)
                    ? "bg-greek-blue text-white"
                    : "border-gray-200 text-gray-700"
                }`}
              >
                <i className={`${filter.icon} text-xs`}></i>
                <span>{filter.label}</span>
              </Button>
            ))}
          </div>

          {searchQuery.length === 0 && (
            <div className="text-center py-12">
              <i className="fas fa-search text-4xl text-gray-300 mb-4"></i>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Search for Parking</h3>
              <p className="text-gray-500">Enter a location, city, or parking name to find available spots</p>
            </div>
          )}

          {searchQuery.length > 0 && isLoading && (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white border border-gray-100 rounded-xl p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-8 w-20" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {searchQuery.length > 0 && !isLoading && parkingLocations && (
            <div className="space-y-4 mb-20">
              {parkingLocations.length === 0 ? (
                <div className="text-center py-12">
                  <i className="fas fa-map-marker-alt text-4xl text-gray-300 mb-4"></i>
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No Results Found</h3>
                  <p className="text-gray-500">Try adjusting your search or filters</p>
                </div>
              ) : (
                parkingLocations.map((location) => (
                  <ParkingCard key={location.id} location={location} />
                ))
              )}
            </div>
          )}
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}

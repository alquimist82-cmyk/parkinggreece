import { useState } from "react";
import { SearchSection } from "@/components/search-section";
import { InteractiveMap } from "@/components/interactive-map";
import { PopularCities } from "@/components/popular-cities";
import { NearbyParking } from "@/components/nearby-parking";
import { BookingModal } from "@/components/booking-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { ParkingLocation } from "@shared/schema";

export default function Home() {
  const [selectedLocation, setSelectedLocation] = useState<ParkingLocation | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [mapMode, setMapMode] = useState<'preview' | 'interactive'>('preview');

  const handleLocationSelect = (location: ParkingLocation) => {
    setSelectedLocation(location);
    setIsBookingModalOpen(true);
  };

  const toggleMapMode = () => {
    setMapMode(prev => prev === 'preview' ? 'interactive' : 'preview');
  };

  return (
    <div>
      <SearchSection />
      
      {/* Enhanced Map Section */}
      <div className="px-4 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Real-time Parking Map</h2>
          <Button 
            variant="outline" 
            size="sm"
            onClick={toggleMapMode}
            className="text-greek-blue border-greek-blue hover:bg-greek-blue hover:text-white"
          >
            <i className={`fas fa-${mapMode === 'preview' ? 'expand' : 'compress'} mr-2`}></i>
            {mapMode === 'preview' ? 'Interactive' : 'Preview'}
          </Button>
        </div>
        
        {mapMode === 'interactive' ? (
          <InteractiveMap 
            onLocationSelect={handleLocationSelect}
            selectedLocationId={selectedLocation?.id}
          />
        ) : (
          <div className="map-container h-64 rounded-xl mb-4 relative overflow-hidden cursor-pointer" onClick={toggleMapMode}>
            <img 
              src="https://images.unsplash.com/photo-1555993539-1732b0258235?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Athens map view" 
              className="w-full h-full object-cover"
            />
            
            {/* Parking Location Markers */}
            <div className="absolute inset-0">
              {/* Marker 1 - Available */}
              <div className="absolute top-1/4 left-1/3 w-6 h-6 bg-available rounded-full border-2 border-white shadow-lg available-pulse flex items-center justify-center">
                <i className="fas fa-parking text-white text-xs"></i>
              </div>
              
              {/* Marker 2 - Limited */}
              <div className="absolute top-1/2 right-1/3 w-6 h-6 bg-limited rounded-full border-2 border-white shadow-lg limited-pulse flex items-center justify-center">
                <i className="fas fa-parking text-white text-xs"></i>
              </div>
              
              {/* Marker 3 - Full */}
              <div className="absolute bottom-1/3 left-1/2 w-6 h-6 bg-full rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                <i className="fas fa-parking text-white text-xs"></i>
              </div>
              
              {/* Interactive overlay */}
              <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-10 transition-all duration-300 flex items-center justify-center">
                <div className="bg-white bg-opacity-90 px-4 py-2 rounded-lg opacity-0 hover:opacity-100 transition-opacity">
                  <span className="text-sm font-medium text-gray-800">Click for interactive map</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Stats Card */}
      <div className="px-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-greek-blue">1,247</div>
                <div className="text-xs text-gray-600">Available Now</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">€2.20</div>
                <div className="text-xs text-gray-600">Avg. Price/hr</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-orange-600">12min</div>
                <div className="text-xs text-gray-600">Avg. Walk</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <PopularCities />
      <NearbyParking onLocationSelect={handleLocationSelect} />

      {/* Booking Modal */}
      {selectedLocation && (
        <BookingModal
          location={selectedLocation}
          isOpen={isBookingModalOpen}
          onClose={() => {
            setIsBookingModalOpen(false);
            setSelectedLocation(null);
          }}
        />
      )}
    </div>
  );
}
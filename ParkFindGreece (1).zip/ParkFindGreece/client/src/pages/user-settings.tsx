import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function UserSettings() {
  const [profile, setProfile] = useState({
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+30 210 1234567",
    language: "en",
  });

  const [notifications, setNotifications] = useState({
    priceAlerts: true,
    bookingReminders: true,
    availabilityAlerts: false,
    marketingEmails: false,
    smsNotifications: true,
  });

  const [privacy, setPrivacy] = useState({
    locationSharing: true,
    usageAnalytics: true,
    personalizedAds: false,
    dataExport: false,
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const saveSettings = useMutation({
    mutationFn: (settings: any) => apiRequest("PATCH", "/api/user/settings", settings),
    onSuccess: () => {
      toast({
        title: "Settings Saved",
        description: "Your preferences have been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveProfile = () => {
    saveSettings.mutate({ type: "profile", data: profile });
  };

  const handleSaveNotifications = () => {
    saveSettings.mutate({ type: "notifications", data: notifications });
  };

  const handleSavePrivacy = () => {
    saveSettings.mutate({ type: "privacy", data: privacy });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-greek-blue rounded-lg flex items-center justify-center">
          <i className="fas fa-user-cog text-white"></i>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Account Settings</h1>
          <p className="text-gray-600">Manage your account preferences and privacy settings</p>
        </div>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-20 h-20 bg-greek-blue rounded-full overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" 
                    alt="Profile picture" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <Button variant="outline" size="sm">
                    <i className="fas fa-camera mr-2"></i>
                    Change Photo
                  </Button>
                  <p className="text-sm text-gray-600 mt-1">JPG, PNG up to 2MB</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={profile.firstName}
                    onChange={(e) => setProfile({ ...profile, firstName: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={profile.lastName}
                    onChange={(e) => setProfile({ ...profile, lastName: e.target.value })}
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Preferred Language</Label>
                <Select value={profile.language} onValueChange={(value) => setProfile({ ...profile, language: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">
                      <div className="flex items-center space-x-2">
                        <span>🇺🇸</span>
                        <span>English</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="el">
                      <div className="flex items-center space-x-2">
                        <span>🇬🇷</span>
                        <span>Ελληνικά</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={handleSaveProfile}
                disabled={saveSettings.isPending}
                className="bg-greek-blue hover:bg-greek-blue/90"
              >
                {saveSettings.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Account Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h3 className="font-medium">Password</h3>
                  <p className="text-sm text-gray-600">Last changed 3 months ago</p>
                </div>
                <Button variant="outline" size="sm">
                  Change Password
                </Button>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h3 className="font-medium">Two-Factor Authentication</h3>
                  <p className="text-sm text-gray-600">Add an extra layer of security</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary">Disabled</Badge>
                  <Button variant="outline" size="sm">
                    Enable
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h3 className="font-medium">Login Sessions</h3>
                  <p className="text-sm text-gray-600">Manage your active sessions</p>
                </div>
                <Button variant="outline" size="sm">
                  View Sessions
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Email Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Price Alerts</h3>
                  <p className="text-sm text-gray-600">Get notified when prices drop below your set limits</p>
                </div>
                <Switch
                  checked={notifications.priceAlerts}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, priceAlerts: checked })}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Booking Reminders</h3>
                  <p className="text-sm text-gray-600">Reminders about your upcoming bookings</p>
                </div>
                <Switch
                  checked={notifications.bookingReminders}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, bookingReminders: checked })}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Availability Alerts</h3>
                  <p className="text-sm text-gray-600">When new spots become available in your saved locations</p>
                </div>
                <Switch
                  checked={notifications.availabilityAlerts}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, availabilityAlerts: checked })}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Marketing Emails</h3>
                  <p className="text-sm text-gray-600">Updates about new features and special offers</p>
                </div>
                <Switch
                  checked={notifications.marketingEmails}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, marketingEmails: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>SMS Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">SMS Alerts</h3>
                  <p className="text-sm text-gray-600">Receive important updates via text message</p>
                </div>
                <Switch
                  checked={notifications.smsNotifications}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, smsNotifications: checked })}
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-info-circle text-blue-600"></i>
                  <p className="text-sm text-blue-800">
                    Standard messaging rates may apply. You can opt out at any time.
                  </p>
                </div>
              </div>

              <Button 
                onClick={handleSaveNotifications}
                disabled={saveSettings.isPending}
                className="bg-greek-blue hover:bg-greek-blue/90"
              >
                Save Notification Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Data & Privacy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Location Sharing</h3>
                  <p className="text-sm text-gray-600">Allow ParkGreece to access your location for better recommendations</p>
                </div>
                <Switch
                  checked={privacy.locationSharing}
                  onCheckedChange={(checked) => setPrivacy({ ...privacy, locationSharing: checked })}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Usage Analytics</h3>
                  <p className="text-sm text-gray-600">Help us improve the app by sharing anonymous usage data</p>
                </div>
                <Switch
                  checked={privacy.usageAnalytics}
                  onCheckedChange={(checked) => setPrivacy({ ...privacy, usageAnalytics: checked })}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Personalized Ads</h3>
                  <p className="text-sm text-gray-600">Show ads based on your parking preferences</p>
                </div>
                <Switch
                  checked={privacy.personalizedAds}
                  onCheckedChange={(checked) => setPrivacy({ ...privacy, personalizedAds: checked })}
                />
              </div>

              <Button 
                onClick={handleSavePrivacy}
                disabled={saveSettings.isPending}
                className="bg-greek-blue hover:bg-greek-blue/90"
              >
                Save Privacy Settings
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <i className="fas fa-download mr-2"></i>
                Download My Data
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <i className="fas fa-trash mr-2"></i>
                Delete Search History
              </Button>
              <Button variant="destructive" className="w-full justify-start">
                <i className="fas fa-user-times mr-2"></i>
                Delete Account
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Billing Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-check-circle text-green-600"></i>
                  <div>
                    <h3 className="font-medium text-green-800">Free Account</h3>
                    <p className="text-sm text-green-700">You're currently on the free plan with basic features.</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Basic Plan</CardTitle>
                    <div className="text-2xl font-bold">Free</div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Find parking locations</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Save favorites</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Basic notifications</span>
                    </div>
                    <Button variant="outline" className="w-full mt-4" disabled>
                      Current Plan
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-greek-blue">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <span>Premium Plan</span>
                      <Badge className="bg-greek-blue text-white">Popular</Badge>
                    </CardTitle>
                    <div className="text-2xl font-bold">€9.99<span className="text-base font-normal">/month</span></div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Everything in Basic</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Advanced booking</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Price alerts</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-600 text-sm"></i>
                      <span className="text-sm">Priority support</span>
                    </div>
                    <Button className="w-full mt-4 bg-greek-blue hover:bg-greek-blue/90">
                      Upgrade Now
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Methods</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <i className="fas fa-credit-card text-gray-400 text-3xl mb-3"></i>
                <p className="text-gray-500">No payment methods added</p>
                <Button variant="outline" className="mt-3">
                  <i className="fas fa-plus mr-2"></i>
                  Add Payment Method
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
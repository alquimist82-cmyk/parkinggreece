import { useQuery } from "@tanstack/react-query";
import { AppHeader } from "@/components/app-header";
import { BottomNavigation } from "@/components/bottom-navigation";
import { ParkingCard } from "@/components/parking-card";
import { Skeleton } from "@/components/ui/skeleton";
import type { ParkingHistory, ParkingLocation } from "@shared/schema";

export default function History() {
  const userId = "user-1"; // Mock user ID

  const { data: history, isLoading: historyLoading } = useQuery<ParkingHistory[]>({
    queryKey: ["/api/history", userId],
  });

  const { data: parkingLocations, isLoading: locationsLoading } = useQuery<ParkingLocation[]>({
    queryKey: ["/api/parking-locations"],
  });

  const isLoading = historyLoading || locationsLoading;

  const historyLocations = parkingLocations?.filter(location =>
    history?.some(h => h.parkingLocationId === location.id)
  ) || [];

  return (
    <div className="bg-gray-50 font-inter min-h-screen">
      <AppHeader />
      <main className="max-w-md mx-auto bg-white min-h-screen">
        <div className="p-4">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center">
              <i className="fas fa-history text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-semibold text-gray-800">Parking History</h1>
          </div>

          {isLoading && (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white border border-gray-100 rounded-xl p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-8 w-20" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {!isLoading && historyLocations.length === 0 && (
            <div className="text-center py-12">
              <i className="fas fa-history text-4xl text-gray-300 mb-4"></i>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No History Yet</h3>
              <p className="text-gray-500">Your parking history will appear here after you visit parking locations</p>
            </div>
          )}

          {!isLoading && historyLocations.length > 0 && (
            <div className="space-y-4 mb-20">
              {historyLocations.map((location) => (
                <ParkingCard key={location.id} location={location} />
              ))}
            </div>
          )}
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}

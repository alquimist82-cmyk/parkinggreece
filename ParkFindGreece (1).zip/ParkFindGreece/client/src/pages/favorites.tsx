import { useQuery } from "@tanstack/react-query";
import { AppHeader } from "@/components/app-header";
import { BottomNavigation } from "@/components/bottom-navigation";
import { ParkingCard } from "@/components/parking-card";
import { Skeleton } from "@/components/ui/skeleton";
import type { UserFavorite, ParkingLocation } from "@shared/schema";

export default function Favorites() {
  const userId = "user-1"; // Mock user ID

  const { data: favorites, isLoading: favoritesLoading } = useQuery<UserFavorite[]>({
    queryKey: ["/api/favorites", userId],
  });

  const { data: parkingLocations, isLoading: locationsLoading } = useQuery<ParkingLocation[]>({
    queryKey: ["/api/parking-locations"],
  });

  const isLoading = favoritesLoading || locationsLoading;

  const favoriteLocations = parkingLocations?.filter(location =>
    favorites?.some(favorite => favorite.parkingLocationId === location.id)
  ) || [];

  return (
    <div className="bg-gray-50 font-inter min-h-screen">
      <AppHeader />
      <main className="max-w-md mx-auto bg-white min-h-screen">
        <div className="p-4">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-heart text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-semibold text-gray-800">Favorite Parking</h1>
          </div>

          {isLoading && (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white border border-gray-100 rounded-xl p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-8 w-20" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {!isLoading && favoriteLocations.length === 0 && (
            <div className="text-center py-12">
              <i className="fas fa-heart text-4xl text-gray-300 mb-4"></i>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Favorites Yet</h3>
              <p className="text-gray-500">Start adding parking locations to your favorites for quick access</p>
            </div>
          )}

          {!isLoading && favoriteLocations.length > 0 && (
            <div className="space-y-4 mb-20">
              {favoriteLocations.map((location) => (
                <ParkingCard key={location.id} location={location} isFavorited />
              ))}
            </div>
          )}
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}

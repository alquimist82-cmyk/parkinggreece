import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function SearchSection() {
  const [searchQuery, setSearchQuery] = useState("");

  const filters = [
    { id: "nearby", label: "Nearby", icon: "fas fa-map-marker-alt", active: true },
    { id: "price", label: "Price", icon: "fas fa-coins", active: false },
    { id: "accessible", label: "Accessible", icon: "fas fa-wheelchair", active: false },
    { id: "24h", label: "24/7", icon: "fas fa-clock", active: false },
  ];

  return (
    <div className="p-4 bg-white">
      {/* Search Bar */}
      <div className="relative mb-4">
        <div className="floating-search relative">
          <i className="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          <Input
            type="text"
            placeholder="Search cities, areas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-12 py-3 border border-gray-200 rounded-xl focus:border-greek-blue focus:ring-2 focus:ring-greek-blue/20 outline-none transition-all"
          />
          <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-greek-blue">
            <i className="fas fa-microphone"></i>
          </button>
        </div>
      </div>

      {/* Quick Location Access */}
      <div className="flex items-center justify-between mb-4">
        <Button className="flex items-center space-x-2 px-4 py-2 bg-greek-blue/10 text-greek-blue hover:bg-greek-blue/20">
          <i className="fas fa-crosshairs text-sm"></i>
          <span className="text-sm font-medium">Current Location</span>
        </Button>
        <Button variant="outline" className="flex items-center space-x-2 px-4 py-2">
          <i className="fas fa-heart text-red-500 text-sm"></i>
          <span className="text-sm font-medium">Favorites</span>
        </Button>
      </div>

      {/* Filter Chips */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {filters.map((filter) => (
          <Button
            key={filter.id}
            variant={filter.active ? "default" : "outline"}
            size="sm"
            className={`flex items-center space-x-2 px-3 py-2 rounded-full text-sm whitespace-nowrap ${
              filter.active 
                ? "bg-greek-blue text-white hover:bg-greek-blue/90" 
                : "border-gray-200 text-gray-700 hover:bg-gray-50"
            }`}
          >
            <i className={`${filter.icon} text-xs`}></i>
            <span>{filter.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}

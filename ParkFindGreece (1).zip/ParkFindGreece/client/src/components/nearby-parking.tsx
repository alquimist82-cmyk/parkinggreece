import { useQuery } from "@tanstack/react-query";
import { ParkingCard } from "@/components/parking-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import type { ParkingLocation } from "@shared/schema";

export function NearbyParking() {
  const { data: parkingLocations, isLoading } = useQuery<ParkingLocation[]>({
    queryKey: ["/api/parking-locations"],
  });

  if (isLoading) {
    return (
      <div className="px-4 mb-20">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Nearby Parking</h2>
          <Button variant="ghost" className="text-greek-blue text-sm font-medium">
            View All
          </Button>
        </div>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-white border border-gray-100 rounded-xl p-4">
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2 mb-3" />
              <div className="flex justify-between items-center">
                <Skeleton className="h-4 w-1/4" />
                <Skeleton className="h-8 w-20" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 mb-20">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-800">Nearby Parking</h2>
        <Button variant="ghost" className="text-greek-blue text-sm font-medium">
          View All
        </Button>
      </div>

      <div className="space-y-3">
        {parkingLocations?.slice(0, 3).map((location) => (
          <ParkingCard key={location.id} location={location} />
        ))}
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { PriceAlert, ParkingLocation } from "@shared/schema";

interface PriceAlertsProps {
  location: ParkingLocation;
}

export function PriceAlerts({ location }: PriceAlertsProps) {
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);
  const [maxPrice, setMaxPrice] = useState(location.pricePerHour);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const userId = "user-1"; // Mock user ID

  const { data: alerts = [] } = useQuery<PriceAlert[]>({
    queryKey: ["/api/price-alerts", userId],
  });

  const existingAlert = alerts.find(alert => 
    alert.parkingLocationId === location.id && alert.isActive
  );

  const createAlert = useMutation({
    mutationFn: (alertData: any) => apiRequest("POST", "/api/price-alerts", alertData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/price-alerts", userId] });
      toast({
        title: "Price Alert Created",
        description: `You'll be notified when ${location.name} drops to €${maxPrice}/hour`,
      });
      setIsAlertModalOpen(false);
    },
  });

  const toggleAlert = useMutation({
    mutationFn: (alertId: string) => apiRequest("PATCH", `/api/price-alerts/${alertId}/toggle`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/price-alerts", userId] });
    },
  });

  const handleCreateAlert = () => {
    if (parseFloat(maxPrice) >= parseFloat(location.pricePerHour)) {
      toast({
        title: "Invalid Price",
        description: "Alert price must be lower than current price",
        variant: "destructive",
      });
      return;
    }

    createAlert.mutate({
      userId,
      parkingLocationId: location.id,
      maxPrice,
      isActive: true,
    });
  };

  const currentPrice = parseFloat(location.pricePerHour);
  const alertPrice = existingAlert ? parseFloat(existingAlert.maxPrice) : 0;
  const savings = currentPrice - alertPrice;

  return (
    <div className="space-y-3">
      {existingAlert ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <i className="fas fa-bell text-yellow-600"></i>
              <span className="text-sm font-medium text-gray-800">Price Alert Active</span>
            </div>
            <Switch
              checked={existingAlert.isActive || false}
              onCheckedChange={() => toggleAlert.mutate(existingAlert.id)}
              disabled={toggleAlert.isPending}
            />
          </div>
          <div className="text-sm text-gray-600">
            <p>Alert when price drops to <span className="font-semibold">€{existingAlert.maxPrice}/hour</span></p>
            <p className="text-green-600">Potential savings: €{savings.toFixed(2)}/hour</p>
          </div>
        </div>
      ) : (
        <Dialog open={isAlertModalOpen} onOpenChange={setIsAlertModalOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="w-full text-greek-blue border-greek-blue hover:bg-greek-blue hover:text-white">
              <i className="fas fa-bell mr-2"></i>
              Set Price Alert
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px] max-w-[95vw] mx-auto">
            <DialogHeader>
              <DialogTitle>Set Price Alert</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-3">
                <h3 className="font-semibold text-gray-800">{location.name}</h3>
                <p className="text-sm text-gray-600">Current price: €{location.pricePerHour}/hour</p>
              </div>

              <div className="space-y-2">
                <Label>Alert me when price drops to:</Label>
                <div className="relative">
                  <Input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    step="0.10"
                    min="0.50"
                    max={parseFloat(location.pricePerHour) - 0.10}
                    className="pr-12"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    €/hour
                  </span>
                </div>
                <p className="text-xs text-gray-500">
                  Must be lower than current price of €{location.pricePerHour}/hour
                </p>
              </div>

              {parseFloat(maxPrice) < parseFloat(location.pricePerHour) && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <div className="flex items-center space-x-2 mb-1">
                    <i className="fas fa-piggy-bank text-green-600"></i>
                    <span className="text-sm font-medium text-green-800">Potential Savings</span>
                  </div>
                  <p className="text-sm text-green-700">
                    €{(parseFloat(location.pricePerHour) - parseFloat(maxPrice)).toFixed(2)} per hour
                  </p>
                </div>
              )}

              <div className="flex space-x-3">
                <Button variant="outline" onClick={() => setIsAlertModalOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateAlert}
                  disabled={createAlert.isPending || parseFloat(maxPrice) >= parseFloat(location.pricePerHour)}
                  className="flex-1 bg-greek-blue hover:bg-greek-blue/90"
                >
                  {createAlert.isPending ? "Creating..." : "Create Alert"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Price History Indicator */}
      <div className="flex items-center justify-between text-xs text-gray-500">
        <span>Price trend:</span>
        <div className="flex items-center space-x-1">
          <i className="fas fa-arrow-down text-green-500"></i>
          <span>-€0.20 this week</span>
        </div>
      </div>
    </div>
  );
}
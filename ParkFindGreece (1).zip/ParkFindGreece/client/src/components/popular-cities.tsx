import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { City } from "@shared/schema";

export function PopularCities() {
  const { data: cities, isLoading } = useQuery<City[]>({
    queryKey: ["/api/cities"],
  });

  const getAvailabilityColor = (available: number) => {
    if (available > 50) return "text-available";
    if (available > 10) return "text-limited";
    return "text-unavailable";
  };

  if (isLoading) {
    return (
      <div className="px-4 mb-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Popular Cities</h2>
        <div className="grid grid-cols-2 gap-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white border border-gray-100 rounded-xl p-4">
              <Skeleton className="w-full h-24 rounded-lg mb-3" />
              <Skeleton className="h-5 w-3/4 mb-2" />
              <div className="flex justify-between">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-1/4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 mb-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Popular Cities</h2>
      <div className="grid grid-cols-2 gap-3">
        {cities?.map((city) => (
          <div key={city.id} className="location-card bg-white border border-gray-100 rounded-xl p-4 cursor-pointer">
            <img 
              src={city.imageUrl || "https://images.unsplash.com/photo-1555993539-1732b0258235?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150"} 
              alt={`${city.name} cityscape`} 
              className="w-full h-24 object-cover rounded-lg mb-3"
            />
            <h3 className="font-semibold text-gray-800 mb-1">{city.name}</h3>
            <div className="flex items-center justify-between text-sm">
              <span className={`font-medium ${getAvailabilityColor(city.availableSpots || 0)}`}>
                {city.availableSpots} available
              </span>
              <span className="text-gray-500">2.3 km</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

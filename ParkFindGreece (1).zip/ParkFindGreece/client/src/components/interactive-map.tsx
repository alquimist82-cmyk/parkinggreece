import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { ParkingLocation } from "@shared/schema";

interface InteractiveMapProps {
  onLocationSelect?: (location: ParkingLocation) => void;
  selectedLocationId?: string;
}

export function InteractiveMap({ onLocationSelect, selectedLocationId }: InteractiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);

  const { data: parkingLocations } = useQuery<ParkingLocation[]>({
    queryKey: ["/api/parking-locations"],
  });

  useEffect(() => {
    if (!mapRef.current) return;

    // Initialize map
    const map = L.map(mapRef.current).setView([37.9755, 23.7348], 13); // Athens center
    mapInstanceRef.current = map;

    // Add tile layer
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
      maxZoom: 19,
    }).addTo(map);

    // Add user location marker
    const userIcon = L.divIcon({
      html: '<div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg"></div>',
      className: 'bg-transparent',
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    L.marker([37.9755, 23.7348], { icon: userIcon })
      .addTo(map)
      .bindPopup("Your Location");

    return () => {
      map.remove();
    };
  }, []);

  useEffect(() => {
    if (!mapInstanceRef.current || !parkingLocations) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Add parking location markers
    parkingLocations.forEach((location) => {
      const lat = parseFloat(location.latitude);
      const lng = parseFloat(location.longitude);
      
      const isSelected = location.id === selectedLocationId;
      const isAvailable = location.availableSpots > 0;
      
      let color = "red";
      if (location.availableSpots > 15) color = "green";
      else if (location.availableSpots > 5) color = "orange";

      const markerIcon = L.divIcon({
        html: `<div class="relative">
          <div class="w-8 h-8 ${isSelected ? 'bg-blue-600' : `bg-${color}-500`} rounded-full border-2 border-white shadow-lg flex items-center justify-center ${isAvailable ? 'animate-pulse' : ''}">
            <i class="fas fa-parking text-white text-xs"></i>
          </div>
          ${isSelected ? '<div class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-blue-600"></div>' : ''}
        </div>`,
        className: 'bg-transparent',
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = L.marker([lat, lng], { icon: markerIcon })
        .addTo(mapInstanceRef.current!)
        .bindPopup(`
          <div class="p-2 min-w-[200px]">
            <h3 class="font-semibold text-gray-800 mb-1">${location.name}</h3>
            <p class="text-sm text-gray-600 mb-2">${location.address}</p>
            <div class="flex justify-between items-center text-sm">
              <span class="font-medium ${isAvailable ? 'text-green-600' : 'text-red-600'}">
                ${location.availableSpots === 0 ? 'Full' : `${location.availableSpots} spots`}
              </span>
              <span class="text-gray-700">€${location.pricePerHour}/hr</span>
            </div>
            <div class="mt-2">
              <button 
                onclick="window.selectParkingLocation('${location.id}')" 
                class="w-full px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600"
              >
                Select
              </button>
            </div>
          </div>
        `);

      marker.on('click', () => {
        if (onLocationSelect) {
          onLocationSelect(location);
        }
      });

      markersRef.current.push(marker);
    });

    // Global function for popup buttons
    (window as any).selectParkingLocation = (locationId: string) => {
      const location = parkingLocations.find(l => l.id === locationId);
      if (location && onLocationSelect) {
        onLocationSelect(location);
      }
    };
  }, [parkingLocations, selectedLocationId, onLocationSelect]);

  return (
    <div className="relative">
      <div 
        ref={mapRef} 
        className="w-full h-64 rounded-xl overflow-hidden shadow-lg"
      />
      
      {/* Map Controls */}
      <div className="absolute top-4 right-4 flex flex-col space-y-2">
        <button 
          onClick={() => mapInstanceRef.current?.setView([37.9755, 23.7348], 13)}
          className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-gray-50"
          title="Center map"
        >
          <i className="fas fa-crosshairs text-gray-600"></i>
        </button>
        <button 
          onClick={() => mapInstanceRef.current?.zoomIn()}
          className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-gray-50"
          title="Zoom in"
        >
          <i className="fas fa-plus text-gray-600"></i>
        </button>
        <button 
          onClick={() => mapInstanceRef.current?.zoomOut()}
          className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-gray-50"
          title="Zoom out"
        >
          <i className="fas fa-minus text-gray-600"></i>
        </button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg px-3 py-2 shadow-md">
        <div className="flex items-center space-x-4 text-xs">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Available</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
            <span>Limited</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span>Full</span>
          </div>
        </div>
      </div>
    </div>
  );
}
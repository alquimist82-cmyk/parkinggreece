import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import type { City, ParkingLocation } from "@shared/schema";

interface AnalyticsDashboardProps {
  cities: City[];
  locations: ParkingLocation[];
}

export function AnalyticsDashboard({ cities, locations }: AnalyticsDashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("7d");

  // Mock analytics data - in real app would come from API
  const occupancyData = [
    { time: '00:00', rate: 15 },
    { time: '06:00', rate: 25 },
    { time: '09:00', rate: 85 },
    { time: '12:00', rate: 92 },
    { time: '15:00', rate: 88 },
    { time: '18:00', rate: 95 },
    { time: '21:00', rate: 65 },
    { time: '23:59', rate: 30 },
  ];

  const revenueData = [
    { day: 'Mon', revenue: 2450 },
    { day: 'Tue', revenue: 3200 },
    { day: 'Wed', revenue: 2800 },
    { day: 'Thu', revenue: 3800 },
    { day: 'Fri', revenue: 4200 },
    { day: 'Sat', revenue: 5100 },
    { day: 'Sun', revenue: 3900 },
  ];

  const cityData = cities.map(city => ({
    name: city.name,
    value: locations.filter(loc => loc.cityId === city.id).length,
    revenue: Math.random() * 5000 + 1000,
  }));

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

  const totalRevenue = revenueData.reduce((sum, item) => sum + item.revenue, 0);
  const totalSpots = locations.reduce((sum, loc) => sum + loc.totalSpots, 0);
  const occupiedSpots = locations.reduce((sum, loc) => sum + (loc.totalSpots - loc.availableSpots), 0);
  const occupancyRate = (occupiedSpots / totalSpots * 100) || 0;
  const avgPrice = locations.reduce((sum, loc) => sum + parseFloat(loc.pricePerHour), 0) / locations.length || 0;

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">€{totalRevenue.toLocaleString()}</div>
              <div className="text-sm text-gray-600">Weekly Revenue</div>
              <div className="text-xs text-green-600 mt-1">+12.5% vs last week</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{occupancyRate.toFixed(1)}%</div>
              <div className="text-sm text-gray-600">Avg Occupancy</div>
              <div className="text-xs text-green-600 mt-1">+3.2% vs last week</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{totalSpots}</div>
              <div className="text-sm text-gray-600">Total Spots</div>
              <div className="text-xs text-blue-600 mt-1">{locations.length} locations</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">€{avgPrice.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Avg Price/hr</div>
              <div className="text-xs text-red-600 mt-1">-€0.15 vs last week</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="occupancy" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="occupancy">Occupancy</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="cities">By City</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="occupancy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Occupancy Rates</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={occupancyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value}%`, 'Occupancy Rate']} />
                  <Line 
                    type="monotone" 
                    dataKey="rate" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cities.slice(0, 4).map(city => {
              const cityLocations = locations.filter(loc => loc.cityId === city.id);
              const cityTotalSpots = cityLocations.reduce((sum, loc) => sum + loc.totalSpots, 0);
              const cityOccupiedSpots = cityLocations.reduce((sum, loc) => sum + (loc.totalSpots - loc.availableSpots), 0);
              const cityOccupancy = (cityOccupiedSpots / cityTotalSpots * 100) || 0;
              
              return (
                <Card key={city.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{city.name}</h3>
                      <Badge variant={cityOccupancy > 80 ? "destructive" : cityOccupancy > 50 ? "default" : "secondary"}>
                        {cityOccupancy.toFixed(1)}%
                      </Badge>
                    </div>
                    <Progress value={cityOccupancy} className="h-2" />
                    <p className="text-sm text-gray-600 mt-2">
                      {cityOccupiedSpots}/{cityTotalSpots} spots occupied
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
        
        <TabsContent value="revenue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`€${value}`, 'Revenue']} />
                  <Bar dataKey="revenue" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="cities" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Locations by City</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={cityData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {cityData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Revenue by City</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {cityData.map((city, index) => (
                    <div key={city.name} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div 
                          className="w-4 h-4 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        ></div>
                        <span className="font-medium">{city.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">€{city.revenue.toFixed(0)}</div>
                        <div className="text-sm text-gray-600">{city.value} locations</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Locations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {locations
                    .sort((a, b) => (b.totalSpots - b.availableSpots) - (a.totalSpots - a.availableSpots))
                    .slice(0, 5)
                    .map((location, index) => {
                      const occupancy = ((location.totalSpots - location.availableSpots) / location.totalSpots * 100) || 0;
                      return (
                        <div key={location.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline">#{index + 1}</Badge>
                              <span className="font-medium">{location.name}</span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">€{location.pricePerHour}/hr</p>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-green-600">{occupancy.toFixed(1)}%</div>
                            <p className="text-sm text-gray-600">
                              {location.totalSpots - location.availableSpots}/{location.totalSpots}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  }
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>System Health</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span>API Response Time</span>
                    <Badge variant="secondary">Excellent</Badge>
                  </div>
                  <Progress value={95} className="h-2" />
                  <p className="text-sm text-gray-600 mt-1">Avg: 120ms</p>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span>Database Performance</span>
                    <Badge variant="secondary">Good</Badge>
                  </div>
                  <Progress value={88} className="h-2" />
                  <p className="text-sm text-gray-600 mt-1">Query time: 45ms</p>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span>Real-time Updates</span>
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  </div>
                  <Progress value={100} className="h-2" />
                  <p className="text-sm text-gray-600 mt-1">Last sync: 2 seconds ago</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, addHours, addDays } from "date-fns";
import type { ParkingLocation } from "@shared/schema";

interface BookingModalProps {
  location: ParkingLocation;
  isOpen: boolean;
  onClose: () => void;
}

export function BookingModal({ location, isOpen, onClose }: BookingModalProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [startTime, setStartTime] = useState("09:00");
  const [duration, setDuration] = useState("2");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const userId = "user-1"; // Mock user ID

  const createBooking = useMutation({
    mutationFn: async (bookingData: any) => {
      return apiRequest("POST", "/api/bookings", bookingData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings", userId] });
      toast({
        title: "Booking Confirmed!",
        description: `Your parking spot at ${location.name} has been reserved.`,
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "There was an error creating your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculatePrice = () => {
    const hours = parseInt(duration);
    const pricePerHour = parseFloat(location.pricePerHour);
    return (hours * pricePerHour).toFixed(2);
  };

  const handleBooking = () => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const startDateTime = new Date(selectedDate);
    startDateTime.setHours(hours, minutes, 0, 0);
    
    const endDateTime = new Date(startDateTime);
    endDateTime.setHours(startDateTime.getHours() + parseInt(duration));

    const bookingData = {
      userId,
      parkingLocationId: location.id,
      startTime: startDateTime.toISOString(),
      endTime: endDateTime.toISOString(),
      totalPrice: calculatePrice(),
      status: "active",
      paymentStatus: "pending",
    };

    createBooking.mutate(bookingData);
  };

  const timeSlots = [
    "08:00", "09:00", "10:00", "11:00", "12:00", "13:00",
    "14:00", "15:00", "16:00", "17:00", "18:00", "19:00",
    "20:00", "21:00", "22:00"
  ];

  const durations = [
    { value: "1", label: "1 hour" },
    { value: "2", label: "2 hours" },
    { value: "3", label: "3 hours" },
    { value: "4", label: "4 hours" },
    { value: "6", label: "6 hours" },
    { value: "8", label: "8 hours" },
    { value: "12", label: "12 hours" },
    { value: "24", label: "24 hours" },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] max-w-[95vw] mx-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Book Parking</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Location Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-semibold text-gray-800">{location.name}</h3>
            <p className="text-sm text-gray-600">{location.address}</p>
            <div className="flex items-center justify-between mt-2 text-sm">
              <span className="text-green-600 font-medium">{location.availableSpots} spots available</span>
              <span className="text-gray-700">€{location.pricePerHour}/hour</span>
            </div>
          </div>

          {/* Date Selection */}
          <div className="space-y-2">
            <Label>Select Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <i className="fas fa-calendar mr-2 text-gray-400"></i>
                  {format(selectedDate, "PPP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Time Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Start Time</Label>
              <Select value={startTime} onValueChange={setStartTime}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((time) => (
                    <SelectItem key={time} value={time}>{time}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Duration</Label>
              <Select value={duration} onValueChange={setDuration}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {durations.map((dur) => (
                    <SelectItem key={dur.value} value={dur.value}>{dur.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Price Summary */}
          <div className="bg-greek-blue/5 rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Duration:</span>
              <span>{duration} hour{parseInt(duration) > 1 ? 's' : ''}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Rate:</span>
              <span>€{location.pricePerHour}/hour</span>
            </div>
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total:</span>
              <span>€{calculatePrice()}</span>
            </div>
          </div>

          {/* Features */}
          <div className="flex flex-wrap gap-2">
            {location.is24Hours && (
              <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">24/7 Access</span>
            )}
            {location.isCovered && (
              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">Covered</span>
            )}
            {location.hasSecurityGuard && (
              <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">Security</span>
            )}
            {location.isAccessible && (
              <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full">Accessible</span>
            )}
            {location.hasEVCharging && (
              <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">EV Charging</span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleBooking}
              disabled={createBooking.isPending || location.availableSpots === 0}
              className="flex-1 bg-greek-blue hover:bg-greek-blue/90"
            >
              {createBooking.isPending ? "Booking..." : `Book for €${calculatePrice()}`}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
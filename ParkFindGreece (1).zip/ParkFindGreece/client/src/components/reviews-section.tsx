import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { ParkingReview } from "@shared/schema";

interface ReviewsSectionProps {
  parkingLocationId: string;
  locationName: string;
}

export function ReviewsSection({ parkingLocationId, locationName }: ReviewsSectionProps) {
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const userId = "user-1"; // Mock user ID

  const { data: reviews = [], isLoading } = useQuery<ParkingReview[]>({
    queryKey: ["/api/reviews", parkingLocationId],
  });

  const submitReview = useMutation({
    mutationFn: (reviewData: any) => apiRequest("POST", "/api/reviews", reviewData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews", parkingLocationId] });
      toast({
        title: "Review Submitted",
        description: "Thank you for your feedback!",
      });
      setIsReviewModalOpen(false);
      setComment("");
      setRating(5);
    },
  });

  const handleSubmitReview = () => {
    if (!comment.trim()) {
      toast({
        title: "Review Required",
        description: "Please write a review comment.",
        variant: "destructive",
      });
      return;
    }

    submitReview.mutate({
      userId,
      parkingLocationId,
      rating,
      comment: comment.trim(),
    });
  };

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length).toFixed(1)
    : "0";

  const renderStars = (rating: number, interactive = false, onRate?: (rating: number) => void) => {
    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => interactive && onRate && onRate(star)}
            className={`${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-transform`}
            disabled={!interactive}
          >
            <i className={`fas fa-star ${star <= rating ? 'text-yellow-400' : 'text-gray-300'} text-lg`}></i>
          </button>
        ))}
      </div>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
          <div className="h-3 bg-gray-200 rounded w-1/4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Rating Summary */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="text-2xl font-bold text-gray-800">{averageRating}</div>
          <div>
            {renderStars(Math.round(parseFloat(averageRating)))}
            <p className="text-sm text-gray-600 mt-1">{reviews.length} review{reviews.length !== 1 ? 's' : ''}</p>
          </div>
        </div>

        <Dialog open={isReviewModalOpen} onOpenChange={setIsReviewModalOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="text-greek-blue border-greek-blue hover:bg-greek-blue hover:text-white">
              <i className="fas fa-plus mr-2"></i>
              Add Review
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px] max-w-[95vw] mx-auto">
            <DialogHeader>
              <DialogTitle>Review {locationName}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Rating</label>
                {renderStars(rating, true, setRating)}
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Your Review</label>
                <Textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Share your experience with this parking location..."
                  rows={4}
                  className="resize-none"
                />
              </div>
              <div className="flex space-x-3">
                <Button variant="outline" onClick={() => setIsReviewModalOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmitReview}
                  disabled={submitReview.isPending}
                  className="flex-1 bg-greek-blue hover:bg-greek-blue/90"
                >
                  {submitReview.isPending ? "Submitting..." : "Submit Review"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Reviews List */}
      {reviews.length > 0 && (
        <div className="space-y-3 max-h-60 overflow-y-auto">
          {reviews.slice(0, 5).map((review) => (
            <div key={review.id} className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {renderStars(review.rating)}
                  <span className="text-sm font-medium text-gray-700">User {review.userId.slice(-3)}</span>
                </div>
                <span className="text-xs text-gray-500">{review.createdAt ? formatDate(review.createdAt.toString()) : 'Recently'}</span>
              </div>
              {review.comment && (
                <p className="text-sm text-gray-700">{review.comment}</p>
              )}
            </div>
          ))}
          {reviews.length > 5 && (
            <Button variant="ghost" size="sm" className="w-full text-greek-blue">
              View all {reviews.length} reviews
            </Button>
          )}
        </div>
      )}

      {reviews.length === 0 && (
        <div className="text-center py-6 text-gray-500">
          <i className="fas fa-star text-3xl text-gray-300 mb-2"></i>
          <p className="text-sm">No reviews yet. Be the first to review this location!</p>
        </div>
      )}
    </div>
  );
}
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ParkingLocation, City } from "@shared/schema";

export function AdminPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<ParkingLocation | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: locations = [] } = useQuery<ParkingLocation[]>({
    queryKey: ["/api/parking-locations"],
  });

  const { data: cities = [] } = useQuery<City[]>({
    queryKey: ["/api/cities"],
  });

  const updateAvailability = useMutation({
    mutationFn: ({ locationId, availableSpots }: { locationId: string; availableSpots: number }) =>
      apiRequest("PATCH", `/api/parking-locations/${locationId}/availability`, { availableSpots }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parking-locations"] });
      toast({
        title: "Availability Updated",
        description: "Parking availability has been updated successfully.",
      });
    },
  });

  const updatePrice = useMutation({
    mutationFn: ({ locationId, pricePerHour }: { locationId: string; pricePerHour: string }) =>
      apiRequest("PATCH", `/api/parking-locations/${locationId}/price`, { pricePerHour }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parking-locations"] });
      toast({
        title: "Price Updated",
        description: "Parking price has been updated successfully.",
      });
    },
  });

  const getAvailabilityColor = (available: number, total: number) => {
    const percentage = (available / total) * 100;
    if (percentage > 50) return "text-green-600";
    if (percentage > 20) return "text-yellow-600";
    return "text-red-600";
  };

  const getAvailabilityBadge = (available: number, total: number) => {
    const percentage = (available / total) * 100;
    if (percentage > 50) return { color: "bg-green-100 text-green-800", label: "Good" };
    if (percentage > 20) return { color: "bg-yellow-100 text-yellow-800", label: "Limited" };
    return { color: "bg-red-100 text-red-800", label: "Critical" };
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="text-purple-600 border-purple-600 hover:bg-purple-50">
          <i className="fas fa-cogs mr-2"></i>
          Admin Panel
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-w-[95vw] mx-auto h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <i className="fas fa-shield-alt text-purple-600"></i>
            <span>ParkGreece Admin Panel</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden">
          <Tabs defaultValue="locations" className="h-full flex flex-col">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="locations">Locations</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="pricing">Pricing</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="locations" className="flex-1 overflow-auto">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {locations.map((location) => {
                    const city = cities.find(c => c.id === location.cityId);
                    const badge = getAvailabilityBadge(location.availableSpots, location.totalSpots);
                    
                    return (
                      <Card key={location.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm font-medium">{location.name}</CardTitle>
                            <Badge className={`text-xs ${badge.color}`}>
                              {badge.label}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-600">{city?.name}</p>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <Label className="text-xs text-gray-500">Available</Label>
                              <div className={`font-bold ${getAvailabilityColor(location.availableSpots, location.totalSpots)}`}>
                                {location.availableSpots}/{location.totalSpots}
                              </div>
                            </div>
                            <div>
                              <Label className="text-xs text-gray-500">Price/hr</Label>
                              <div className="font-bold text-greek-blue">€{location.pricePerHour}</div>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <Label className="text-xs">Update Availability</Label>
                              <div className="flex space-x-2 mt-1">
                                <Input
                                  type="number"
                                  min="0"
                                  max={location.totalSpots}
                                  defaultValue={location.availableSpots}
                                  className="flex-1 h-8 text-sm"
                                  id={`availability-${location.id}`}
                                />
                                <Button
                                  size="sm"
                                  onClick={() => {
                                    const input = document.getElementById(`availability-${location.id}`) as HTMLInputElement;
                                    const availableSpots = parseInt(input.value);
                                    updateAvailability.mutate({ locationId: location.id, availableSpots });
                                  }}
                                  disabled={updateAvailability.isPending}
                                  className="px-3 h-8 text-xs"
                                >
                                  Update
                                </Button>
                              </div>
                            </div>

                            <div>
                              <Label className="text-xs">Update Price (€/hr)</Label>
                              <div className="flex space-x-2 mt-1">
                                <Input
                                  type="number"
                                  step="0.10"
                                  min="0.50"
                                  defaultValue={location.pricePerHour}
                                  className="flex-1 h-8 text-sm"
                                  id={`price-${location.id}`}
                                />
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    const input = document.getElementById(`price-${location.id}`) as HTMLInputElement;
                                    const pricePerHour = input.value;
                                    updatePrice.mutate({ locationId: location.id, pricePerHour });
                                  }}
                                  disabled={updatePrice.isPending}
                                  className="px-3 h-8 text-xs"
                                >
                                  Update
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="analytics" className="flex-1 overflow-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-greek-blue">{locations.length}</div>
                      <div className="text-sm text-gray-600">Total Locations</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {locations.reduce((sum, loc) => sum + loc.availableSpots, 0)}
                      </div>
                      <div className="text-sm text-gray-600">Available Spots</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {locations.reduce((sum, loc) => sum + loc.totalSpots, 0)}
                      </div>
                      <div className="text-sm text-gray-600">Total Spots</div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">
                        €{(locations.reduce((sum, loc) => sum + parseFloat(loc.pricePerHour), 0) / locations.length || 0).toFixed(2)}
                      </div>
                      <div className="text-sm text-gray-600">Avg Price/hr</div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Location Status Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {cities.map(city => {
                      const cityLocations = locations.filter(loc => loc.cityId === city.id);
                      const totalSpots = cityLocations.reduce((sum, loc) => sum + loc.totalSpots, 0);
                      const availableSpots = cityLocations.reduce((sum, loc) => sum + loc.availableSpots, 0);
                      const occupancyRate = ((totalSpots - availableSpots) / totalSpots * 100) || 0;
                      
                      return (
                        <div key={city.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <h3 className="font-medium">{city.name}</h3>
                            <p className="text-sm text-gray-600">{cityLocations.length} locations</p>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold">{occupancyRate.toFixed(1)}%</div>
                            <div className="text-sm text-gray-600">Occupied</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="pricing" className="flex-1 overflow-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Pricing by City</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {cities.map(city => {
                        const cityLocations = locations.filter(loc => loc.cityId === city.id);
                        const avgPrice = cityLocations.reduce((sum, loc) => sum + parseFloat(loc.pricePerHour), 0) / cityLocations.length || 0;
                        const minPrice = Math.min(...cityLocations.map(loc => parseFloat(loc.pricePerHour)));
                        const maxPrice = Math.max(...cityLocations.map(loc => parseFloat(loc.pricePerHour)));
                        
                        return (
                          <div key={city.id} className="p-4 border rounded-lg">
                            <h3 className="font-semibold mb-2">{city.name}</h3>
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <div className="text-gray-600">Average</div>
                                <div className="font-bold text-greek-blue">€{avgPrice.toFixed(2)}</div>
                              </div>
                              <div>
                                <div className="text-gray-600">Min</div>
                                <div className="font-bold text-green-600">€{minPrice.toFixed(2)}</div>
                              </div>
                              <div>
                                <div className="text-gray-600">Max</div>
                                <div className="font-bold text-red-600">€{maxPrice.toFixed(2)}</div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Bulk Price Update</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <Label>Select City</Label>
                        <select className="w-full mt-1 p-2 border rounded">
                          <option value="">All Cities</option>
                          {cities.map(city => (
                            <option key={city.id} value={city.id}>{city.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <Label>Price Adjustment</Label>
                        <div className="flex space-x-2 mt-1">
                          <select className="p-2 border rounded">
                            <option value="increase">Increase by</option>
                            <option value="decrease">Decrease by</option>
                            <option value="set">Set to</option>
                          </select>
                          <Input type="number" step="0.10" placeholder="€0.50" className="flex-1" />
                        </div>
                      </div>
                      <Button className="w-full bg-greek-blue hover:bg-greek-blue/90">
                        Apply Price Changes
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="settings" className="flex-1 overflow-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>System Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Real-time Updates</Label>
                        <p className="text-sm text-gray-600">Enable live availability updates</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Price Alerts</Label>
                        <p className="text-sm text-gray-600">Send notifications for price changes</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Auto-pricing</Label>
                        <p className="text-sm text-gray-600">Dynamic pricing based on demand</p>
                      </div>
                      <Switch />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Data Management</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <i className="fas fa-download mr-2"></i>
                      Export All Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <i className="fas fa-upload mr-2"></i>
                      Import Locations
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <i className="fas fa-sync-alt mr-2"></i>
                      Sync with External APIs
                    </Button>
                    <Button variant="destructive" className="w-full justify-start">
                      <i className="fas fa-trash mr-2"></i>
                      Clear Old Data
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

type Language = 'en' | 'el';

interface LanguageSwitcherProps {
  currentLanguage?: Language;
  onLanguageChange?: (language: Language) => void;
}

const languages = {
  en: { name: 'English', flag: '🇺🇸' },
  el: { name: 'Ελληνικά', flag: '🇬🇷' }
};

export function LanguageSwitcher({ 
  currentLanguage = 'en', 
  onLanguageChange 
}: LanguageSwitcherProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(currentLanguage);

  const handleLanguageChange = (language: Language) => {
    setSelectedLanguage(language);
    onLanguageChange?.(language);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 px-2">
          <span className="mr-2">{languages[selectedLanguage].flag}</span>
          <span className="text-xs">{languages[selectedLanguage].name}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {Object.entries(languages).map(([code, language]) => (
          <DropdownMenuItem
            key={code}
            onClick={() => handleLanguageChange(code as Language)}
            className="flex items-center space-x-2"
          >
            <span>{language.flag}</span>
            <span>{language.name}</span>
            {code === selectedLanguage && (
              <i className="fas fa-check text-greek-blue ml-auto"></i>
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
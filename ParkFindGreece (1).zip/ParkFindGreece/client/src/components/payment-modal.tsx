import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import type { ParkingBooking } from "@shared/schema";

interface PaymentModalProps {
  booking: ParkingBooking;
  locationName: string;
  isOpen: boolean;
  onClose: () => void;
}

export function PaymentModal({ booking, locationName, isOpen, onClose }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardName, setCardName] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const userId = "user-1"; // Mock user ID

  const processPayment = useMutation({
    mutationFn: async (paymentData: any) => {
      setIsProcessing(true);
      // Simulate payment processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      return apiRequest("POST", `/api/bookings/${booking.id}/payment`, paymentData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings", userId] });
      toast({
        title: "Payment Successful!",
        description: `Your parking spot at ${locationName} is confirmed.`,
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Payment Failed",
        description: "Please check your payment details and try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsProcessing(false);
    },
  });

  const handlePayment = () => {
    if (!cardNumber || !expiryDate || !cvv || !cardName) {
      toast({
        title: "Missing Information",
        description: "Please fill in all payment details.",
        variant: "destructive",
      });
      return;
    }

    processPayment.mutate({
      paymentMethod,
      cardNumber: cardNumber.replace(/\s/g, ''),
      expiryDate,
      cvv,
      cardName,
      amount: parseFloat(booking.totalPrice),
    });
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  const bookingDuration = Math.ceil(
    (new Date(booking.endTime).getTime() - new Date(booking.startTime).getTime()) / (1000 * 60 * 60)
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] max-w-[95vw] mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <i className="fas fa-credit-card text-greek-blue"></i>
            <span>Secure Payment</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Booking Summary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Booking Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Location:</span>
                <span className="font-medium">{locationName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Date & Time:</span>
                <span className="font-medium">
                  {new Date(booking.startTime).toLocaleDateString()} at{' '}
                  {new Date(booking.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Duration:</span>
                <span className="font-medium">{bookingDuration} hour{bookingDuration !== 1 ? 's' : ''}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Total:</span>
                <span className="text-greek-blue">€{booking.totalPrice}</span>
              </div>
            </CardContent>
          </Card>

          {/* Payment Method */}
          <div>
            <Label className="text-base font-medium">Payment Method</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="card">
                  <div className="flex items-center space-x-2">
                    <i className="fas fa-credit-card"></i>
                    <span>Credit/Debit Card</span>
                  </div>
                </SelectItem>
                <SelectItem value="paypal">
                  <div className="flex items-center space-x-2">
                    <i className="fab fa-paypal"></i>
                    <span>PayPal</span>
                  </div>
                </SelectItem>
                <SelectItem value="googlepay">
                  <div className="flex items-center space-x-2">
                    <i className="fab fa-google-pay"></i>
                    <span>Google Pay</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {paymentMethod === "card" && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Card Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Cardholder Name</Label>
                  <Input
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="John Doe"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Card Number</Label>
                  <Input
                    value={cardNumber}
                    onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                    className="mt-1"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Expiry Date</Label>
                    <Input
                      value={expiryDate}
                      onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
                      placeholder="MM/YY"
                      maxLength={5}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>CVV</Label>
                    <Input
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').substring(0, 3))}
                      placeholder="123"
                      maxLength={3}
                      className="mt-1"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {paymentMethod !== "card" && (
            <Card>
              <CardContent className="p-6 text-center">
                <div className="space-y-4">
                  <div className="text-4xl">
                    {paymentMethod === "paypal" && <i className="fab fa-paypal text-blue-600"></i>}
                    {paymentMethod === "googlepay" && <i className="fab fa-google-pay text-green-600"></i>}
                  </div>
                  <p className="text-gray-600">
                    You will be redirected to {paymentMethod === "paypal" ? "PayPal" : "Google Pay"} to complete your payment.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Security Notice */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex items-center space-x-2 text-green-800">
              <i className="fas fa-shield-alt"></i>
              <span className="text-sm font-medium">Secure Payment</span>
            </div>
            <p className="text-sm text-green-700 mt-1">
              Your payment information is encrypted and secure. We don't store your card details.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isProcessing}
            >
              Cancel
            </Button>
            <Button
              onClick={handlePayment}
              disabled={isProcessing}
              className="flex-1 bg-greek-blue hover:bg-greek-blue/90"
            >
              {isProcessing ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                  <span>Processing...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <i className="fas fa-lock"></i>
                  <span>Pay €{booking.totalPrice}</span>
                </div>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { BookingModal } from "@/components/booking-modal";
import { ReviewsSection } from "@/components/reviews-section";
import { PriceAlerts } from "@/components/price-alerts";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { apiRequest } from "@/lib/queryClient";
import type { ParkingLocation } from "@shared/schema";

interface ParkingCardProps {
  location: ParkingLocation;
  isFavorited?: boolean;
}

export function ParkingCard({ location, isFavorited = false }: ParkingCardProps) {
  const [isLiked, setIsLiked] = useState(isFavorited);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const queryClient = useQueryClient();
  const userId = "user-1"; // Mock user ID

  const getAvailabilityColor = (available: number) => {
    if (available > 15) return "text-available";
    if (available > 5) return "text-limited";
    return "text-unavailable";
  };

  const getAvailabilityBadgeColor = (available: number) => {
    if (available > 15) return "bg-available";
    if (available > 5) return "bg-limited";
    return "bg-unavailable";
  };

  const addToFavorites = useMutation({
    mutationFn: () => apiRequest("POST", "/api/favorites", {
      userId,
      parkingLocationId: location.id
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites", userId] });
      setIsLiked(true);
    },
  });

  const removeFromFavorites = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/favorites/${userId}/${location.id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites", userId] });
      setIsLiked(false);
    },
  });

  const addToHistory = useMutation({
    mutationFn: () => apiRequest("POST", "/api/history", {
      userId,
      parkingLocationId: location.id
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history", userId] });
    },
  });

  const handleFavoriteToggle = () => {
    if (isLiked) {
      removeFromFavorites.mutate();
    } else {
      addToFavorites.mutate();
    }
  };

  const handleNavigate = () => {
    addToHistory.mutate();
    // Open navigation in external app
    const url = `https://www.google.com/maps/dir/?api=1&destination=${location.latitude},${location.longitude}`;
    window.open(url, '_blank');
  };

  return (
    <div className="bg-white border border-gray-100 rounded-xl p-4 mb-3">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-800 mb-1">{location.name}</h3>
          <p className="text-sm text-gray-600 mb-2">{location.address}</p>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1">
              <div className={`w-2 h-2 ${getAvailabilityBadgeColor(location.availableSpots)} rounded-full`}></div>
              <span className={`font-medium ${getAvailabilityColor(location.availableSpots)}`}>
                {location.availableSpots === 0 ? "Full" : `${location.availableSpots} available`}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <i className="fas fa-euro-sign text-gray-400 text-xs"></i>
              <span className="text-gray-700">€{location.pricePerHour}/hr</span>
            </div>
            <div className="flex items-center space-x-1">
              <i className="fas fa-walking text-gray-400 text-xs"></i>
              <span className="text-gray-700">{location.distance}km</span>
            </div>
          </div>
        </div>
        <button 
          onClick={handleFavoriteToggle}
          className={`ml-3 ${isLiked ? "text-red-500" : "text-gray-400 hover:text-red-500"}`}
          disabled={addToFavorites.isPending || removeFromFavorites.isPending}
        >
          <i className={isLiked ? "fas fa-heart" : "far fa-heart"}></i>
        </button>
      </div>
      
      <div className="flex items-center justify-between mb-3">
        <div className="flex space-x-2">
          {location.is24Hours && (
            <span className="px-2 py-1 bg-available/10 text-available text-xs rounded-full">24/7</span>
          )}
          {location.isCovered && (
            <span className="px-2 py-1 bg-greek-blue/10 text-greek-blue text-xs rounded-full">Covered</span>
          )}
          {location.hasSecurityGuard && (
            <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">Security</span>
          )}
          {location.isAccessible && (
            <span className="px-2 py-1 bg-blue-100 text-blue-600 text-xs rounded-full">Accessible</span>
          )}
          {location.hasEVCharging && (
            <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">EV Charging</span>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-2 mb-3">
        <Button 
          onClick={() => setIsBookingModalOpen(true)}
          disabled={location.availableSpots === 0}
          className={`flex-1 text-sm ${
            location.availableSpots === 0 
              ? "bg-gray-200 text-gray-500 cursor-not-allowed" 
              : "bg-greek-blue text-white hover:bg-greek-blue/90"
          }`}
        >
          <i className="fas fa-calendar-alt mr-2"></i>
          {location.availableSpots === 0 ? "Full" : "Book Now"}
        </Button>
        
        <Button 
          onClick={handleNavigate}
          variant="outline"
          disabled={location.availableSpots === 0 || addToHistory.isPending}
          className="flex-1 text-sm"
        >
          <i className="fas fa-navigation mr-2"></i>
          Navigate
        </Button>
      </div>

      {/* Expandable Details */}
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="w-full text-greek-blue hover:bg-greek-blue/10">
            <span className="mr-2">View Details</span>
            <i className={`fas fa-chevron-${isExpanded ? 'up' : 'down'}`}></i>
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-4 mt-4 pt-4 border-t border-gray-100">
          <ReviewsSection parkingLocationId={location.id} locationName={location.name} />
          <PriceAlerts location={location} />
        </CollapsibleContent>
      </Collapsible>

      {/* Booking Modal */}
      <BookingModal
        location={location}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
      />
    </div>
  );
}

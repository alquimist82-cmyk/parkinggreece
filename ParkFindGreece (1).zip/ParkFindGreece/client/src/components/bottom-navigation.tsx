import { useLocation } from "wouter";
import { Link } from "wouter";

export function BottomNavigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: "fas fa-map", label: "Map" },
    { path: "/search", icon: "fas fa-search", label: "Search" },
    { path: "/favorites", icon: "fas fa-heart", label: "Favorites" },
    { path: "/history", icon: "fas fa-history", label: "History" },
    { path: "/profile", icon: "fas fa-user", label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 max-w-md mx-auto z-50">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const isActive = location === item.path;
          return (
            <Link key={item.path} href={item.path}>
              <button 
                className={`flex flex-col items-center space-y-1 py-2 px-4 ${
                  isActive ? "text-greek-blue" : "text-gray-400"
                }`}
              >
                <i className={`${item.icon} text-lg`}></i>
                <span className={`text-xs ${isActive ? "font-medium" : ""}`}>
                  {item.label}
                </span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

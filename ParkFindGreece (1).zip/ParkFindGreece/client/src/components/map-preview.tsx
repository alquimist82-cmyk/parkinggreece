export function MapPreview() {
  return (
    <div className="map-container h-64 mx-4 rounded-xl mb-4 relative overflow-hidden">
      {/* Map background with parking location markers */}
      <img 
        src="https://images.unsplash.com/photo-1555993539-1732b0258235?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
        alt="Athens map view" 
        className="w-full h-full object-cover"
      />
      
      {/* Parking Location Markers */}
      <div className="absolute inset-0">
        {/* Marker 1 - Available */}
        <div className="absolute top-1/4 left-1/3 w-6 h-6 bg-available rounded-full border-2 border-white shadow-lg available-pulse flex items-center justify-center">
          <i className="fas fa-parking text-white text-xs"></i>
        </div>
        {/* Marker 2 - Limited */}
        <div className="absolute top-1/2 right-1/4 w-6 h-6 bg-limited rounded-full border-2 border-white shadow-lg flex items-center justify-center">
          <i className="fas fa-parking text-white text-xs"></i>
        </div>
        {/* Marker 3 - Unavailable */}
        <div className="absolute bottom-1/3 left-1/2 w-6 h-6 bg-unavailable rounded-full border-2 border-white shadow-lg flex items-center justify-center">
          <i className="fas fa-parking text-white text-xs"></i>
        </div>
      </div>

      {/* Map Controls */}
      <div className="absolute top-4 right-4 flex flex-col space-y-2">
        <button className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-gray-50">
          <i className="fas fa-expand text-gray-600"></i>
        </button>
        <button className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-gray-50">
          <i className="fas fa-layer-group text-gray-600"></i>
        </button>
      </div>

      {/* Current Location Indicator */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg px-3 py-2 shadow-md flex items-center space-x-2">
        <div className="w-2 h-2 bg-greek-blue rounded-full"></div>
        <span className="text-sm text-gray-700">Your Location</span>
      </div>
    </div>
  );
}

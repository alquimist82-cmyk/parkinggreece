import { NotificationCenter } from "@/components/notifications";
import { LanguageSwitcher } from "@/components/language-switcher";
import { AdminPanel } from "@/components/admin-panel";

export function AppHeader() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-md mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-greek-blue rounded-lg flex items-center justify-center">
              <i className="fas fa-parking text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-semibold text-gray-800">ParkGreece</h1>
          </div>
          <div className="flex items-center space-x-2">
            <AdminPanel />
            <LanguageSwitcher />
            <NotificationCenter />
            <button className="w-8 h-8 bg-greek-blue rounded-full overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" 
                alt="User avatar" 
                className="w-full h-full object-cover"
              />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { DatabaseStorage } from "./database-storage";
import { 
  insertParkingBookingSchema,
  insertParkingReviewSchema,
  insertPriceAlertSchema,
  insertNotificationSchema
} from "@shared/schema";

const storage = new DatabaseStorage();
import { insertParkingLocationSchema, insertUserFavoriteSchema, insertParkingHistorySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Cities routes
  app.get("/api/cities", async (req, res) => {
    try {
      const cities = await storage.getCities();
      res.json(cities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cities" });
    }
  });

  app.get("/api/cities/:id", async (req, res) => {
    try {
      const city = await storage.getCityById(req.params.id);
      if (!city) {
        return res.status(404).json({ message: "City not found" });
      }
      res.json(city);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch city" });
    }
  });

  // Parking locations routes
  app.get("/api/parking-locations", async (req, res) => {
    try {
      const { cityId, search } = req.query;
      
      let locations;
      if (cityId) {
        locations = await storage.getParkingLocationsByCity(cityId as string);
      } else if (search) {
        locations = await storage.searchParkingLocations(search as string);
      } else {
        locations = await storage.getParkingLocations();
      }
      
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch parking locations" });
    }
  });

  app.get("/api/parking-locations/:id", async (req, res) => {
    try {
      const location = await storage.getParkingLocationById(req.params.id);
      if (!location) {
        return res.status(404).json({ message: "Parking location not found" });
      }
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch parking location" });
    }
  });

  app.post("/api/parking-locations", async (req, res) => {
    try {
      const validatedData = insertParkingLocationSchema.parse(req.body);
      const location = await storage.createParkingLocation(validatedData);
      res.status(201).json(location);
    } catch (error) {
      res.status(400).json({ message: "Invalid parking location data" });
    }
  });

  app.patch("/api/parking-locations/:id/availability", async (req, res) => {
    try {
      const { availableSpots } = req.body;
      const location = await storage.updateParkingAvailability(req.params.id, availableSpots);
      if (!location) {
        return res.status(404).json({ message: "Parking location not found" });
      }
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Failed to update availability" });
    }
  });

  // User favorites routes
  app.get("/api/favorites/:userId", async (req, res) => {
    try {
      const favorites = await storage.getUserFavorites(req.params.userId);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", async (req, res) => {
    try {
      const validatedData = insertUserFavoriteSchema.parse(req.body);
      const favorite = await storage.addUserFavorite(validatedData);
      res.status(201).json(favorite);
    } catch (error) {
      res.status(400).json({ message: "Invalid favorite data" });
    }
  });

  app.delete("/api/favorites/:userId/:parkingLocationId", async (req, res) => {
    try {
      const { userId, parkingLocationId } = req.params;
      const success = await storage.removeUserFavorite(userId, parkingLocationId);
      if (!success) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // Parking history routes
  app.get("/api/history/:userId", async (req, res) => {
    try {
      const history = await storage.getUserParkingHistory(req.params.userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch parking history" });
    }
  });

  app.post("/api/history", async (req, res) => {
    try {
      const validatedData = insertParkingHistorySchema.parse(req.body);
      const history = await storage.addParkingHistory(validatedData);
      res.status(201).json(history);
    } catch (error) {
      res.status(400).json({ message: "Invalid history data" });
    }
  });

  // Booking routes
  app.get("/api/bookings/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const bookings = await storage.getUserBookings(userId);
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ error: "Failed to fetch bookings" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const result = insertParkingBookingSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      
      const booking = await storage.createBooking(result.data);
      
      // Create notification
      await storage.createNotification({
        userId: booking.userId,
        type: "booking_confirmed",
        title: "Booking Confirmed",
        message: `Your parking spot has been reserved for ${new Date(booking.startTime).toLocaleDateString()}`,
        relatedId: booking.id,
      });
      
      res.json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(500).json({ error: "Failed to create booking" });
    }
  });

  app.post("/api/bookings/:bookingId/payment", async (req, res) => {
    try {
      const { bookingId } = req.params;
      
      // Simulate payment processing
      const booking = await storage.updateBookingPaymentStatus(bookingId, "paid");
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }

      // Create payment success notification
      await storage.createNotification({
        userId: booking.userId,
        type: "payment_success",
        title: "Payment Successful",
        message: `Payment of €${booking.totalPrice} has been processed successfully.`,
        relatedId: bookingId,
      });

      res.json({ success: true, booking });
    } catch (error) {
      console.error("Error processing payment:", error);
      res.status(500).json({ error: "Payment processing failed" });
    }
  });

  // Review routes
  app.get("/api/reviews/:parkingLocationId", async (req, res) => {
    try {
      const { parkingLocationId } = req.params;
      const reviews = await storage.getLocationReviews(parkingLocationId);
      const averageRating = await storage.getLocationAverageRating(parkingLocationId);
      
      res.json({
        reviews,
        averageRating,
        totalReviews: reviews.length
      });
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      const result = insertParkingReviewSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      
      const review = await storage.createReview(result.data);
      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ error: "Failed to create review" });
    }
  });

  // Price alert routes
  app.get("/api/price-alerts/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const alerts = await storage.getUserPriceAlerts(userId);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching price alerts:", error);
      res.status(500).json({ error: "Failed to fetch price alerts" });
    }
  });

  app.post("/api/price-alerts", async (req, res) => {
    try {
      const result = insertPriceAlertSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      
      const alert = await storage.createPriceAlert(result.data);
      res.json(alert);
    } catch (error) {
      console.error("Error creating price alert:", error);
      res.status(500).json({ error: "Failed to create price alert" });
    }
  });

  app.patch("/api/price-alerts/:alertId/toggle", async (req, res) => {
    try {
      const { alertId } = req.params;
      const alert = await storage.togglePriceAlert(alertId);
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json(alert);
    } catch (error) {
      console.error("Error toggling price alert:", error);
      res.status(500).json({ error: "Failed to toggle price alert" });
    }
  });

  // Notification routes
  app.get("/api/notifications/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:notificationId/read", async (req, res) => {
    try {
      const { notificationId } = req.params;
      const notification = await storage.markNotificationAsRead(notificationId);
      if (!notification) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  app.patch("/api/notifications/:userId/read-all", async (req, res) => {
    try {
      const { userId } = req.params;
      await storage.markAllNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ error: "Failed to mark notifications as read" });
    }
  });

  // Admin routes
  app.patch("/api/parking-locations/:locationId/availability", async (req, res) => {
    try {
      const { locationId } = req.params;
      const { availableSpots } = req.body;
      
      const location = await storage.updateParkingAvailability(locationId, availableSpots);
      if (!location) {
        return res.status(404).json({ error: "Location not found" });
      }
      
      res.json(location);
    } catch (error) {
      console.error("Error updating availability:", error);
      res.status(500).json({ error: "Failed to update availability" });
    }
  });

  app.patch("/api/parking-locations/:locationId/price", async (req, res) => {
    try {
      const { locationId } = req.params;
      const { pricePerHour } = req.body;
      
      // This would need to be implemented in DatabaseStorage
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating price:", error);
      res.status(500).json({ error: "Failed to update price" });
    }
  });

  // Initialize database with sample data
  await storage.initializeData();

  const httpServer = createServer(app);
  return httpServer;
}

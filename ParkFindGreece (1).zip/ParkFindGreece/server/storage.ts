import { type City, type ParkingLocation, type UserFavorite, type ParkingHistory, type InsertCity, type InsertParkingLocation, type InsertUserFavorite, type InsertParkingHistory } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Cities
  getCities(): Promise<City[]>;
  getCityById(id: string): Promise<City | undefined>;
  createCity(city: InsertCity): Promise<City>;
  
  // Parking Locations
  getParkingLocations(): Promise<ParkingLocation[]>;
  getParkingLocationById(id: string): Promise<ParkingLocation | undefined>;
  getParkingLocationsByCity(cityId: string): Promise<ParkingLocation[]>;
  searchParkingLocations(query: string): Promise<ParkingLocation[]>;
  createParkingLocation(location: InsertParkingLocation): Promise<ParkingLocation>;
  updateParkingAvailability(id: string, availableSpots: number): Promise<ParkingLocation | undefined>;
  
  // User Favorites
  getUserFavorites(userId: string): Promise<UserFavorite[]>;
  addUserFavorite(favorite: InsertUserFavorite): Promise<UserFavorite>;
  removeUserFavorite(userId: string, parkingLocationId: string): Promise<boolean>;
  
  // Parking History
  getUserParkingHistory(userId: string): Promise<ParkingHistory[]>;
  addParkingHistory(history: InsertParkingHistory): Promise<ParkingHistory>;
}

export class MemStorage implements IStorage {
  private cities: Map<string, City>;
  private parkingLocations: Map<string, ParkingLocation>;
  private userFavorites: Map<string, UserFavorite>;
  private parkingHistory: Map<string, ParkingHistory>;

  constructor() {
    this.cities = new Map();
    this.parkingLocations = new Map();
    this.userFavorites = new Map();
    this.parkingHistory = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize Greek cities with comprehensive coverage
    const cities: City[] = [
      {
        id: "1",
        name: "Athens",
        region: "Attica",
        latitude: "37.9838",
        longitude: "23.7275",
        imageUrl: "https://images.unsplash.com/photo-1555993539-1732b0258235?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 2500,
        availableSpots: 142,
      },
      {
        id: "2",
        name: "Thessaloniki",
        region: "Central Macedonia",
        latitude: "40.6401",
        longitude: "22.9444",
        imageUrl: "https://images.unsplash.com/photo-1580654712603-eb43273aff33?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 800,
        availableSpots: 23,
      },
      {
        id: "3",
        name: "Patras",
        region: "Western Greece",
        latitude: "38.2466",
        longitude: "21.7346",
        imageUrl: "https://images.unsplash.com/photo-1590227877385-b72d2c27b0a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 600,
        availableSpots: 67,
      },
      {
        id: "4",
        name: "Heraklion",
        region: "Crete",
        latitude: "35.3387",
        longitude: "25.1442",
        imageUrl: "https://images.unsplash.com/photo-1576485290814-1c72aa4bbb8e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 400,
        availableSpots: 3,
      },
      {
        id: "5",
        name: "Rhodes",
        region: "South Aegean",
        latitude: "36.4341",
        longitude: "28.2176",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 350,
        availableSpots: 45,
      },
      {
        id: "6",
        name: "Mykonos",
        region: "South Aegean",
        latitude: "37.4415",
        longitude: "25.3667",
        imageUrl: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 200,
        availableSpots: 8,
      },
      {
        id: "7",
        name: "Santorini",
        region: "South Aegean",
        latitude: "36.3932",
        longitude: "25.4615",
        imageUrl: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 180,
        availableSpots: 0,
      },
      {
        id: "8",
        name: "Volos",
        region: "Thessaly",
        latitude: "39.3617",
        longitude: "22.9444",
        imageUrl: "https://images.unsplash.com/photo-1580837119756-563d608dd119?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 450,
        availableSpots: 78,
      },
      {
        id: "9",
        name: "Larissa",
        region: "Thessaly",
        latitude: "39.6390",
        longitude: "22.4194",
        imageUrl: "https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 520,
        availableSpots: 89,
      },
      {
        id: "10",
        name: "Chania",
        region: "Crete",
        latitude: "35.5138",
        longitude: "24.0180",
        imageUrl: "https://images.unsplash.com/photo-1539650116574-75c0c6d5d3a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 380,
        availableSpots: 56,
      },
    ];

    cities.forEach(city => this.cities.set(city.id, city));

    // Initialize parking locations across Greece
    const parkingLocations: ParkingLocation[] = [
      // Athens Locations
      {
        id: "p1",
        name: "Central Athens Parking",
        address: "Syntagma Square, Athens Center",
        cityId: "1",
        latitude: "37.9755",
        longitude: "23.7348",
        totalSpots: 150,
        availableSpots: 24,
        pricePerHour: "2.50",
        is24Hours: true,
        isCovered: true,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: false,
        tags: ["24/7", "Covered", "Security"],
        distance: "0.15",
        updatedAt: new Date(),
      },
      {
        id: "p2",
        name: "Marina Parking",
        address: "Flisvos Marina, Paleo Faliro",
        cityId: "1",
        latitude: "37.9311",
        longitude: "23.6967",
        totalSpots: 80,
        availableSpots: 7,
        pricePerHour: "3.00",
        is24Hours: true,
        isCovered: false,
        hasSecurityGuard: false,
        isAccessible: true,
        hasEVCharging: true,
        tags: ["24/7", "Outdoor", "Sea View"],
        distance: "0.32",
        updatedAt: new Date(),
      },
      {
        id: "p3",
        name: "Airport Parking",
        address: "Athens International Airport",
        cityId: "1",
        latitude: "37.9364",
        longitude: "23.9445",
        totalSpots: 1200,
        availableSpots: 0,
        pricePerHour: "8.00",
        is24Hours: true,
        isCovered: true,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: true,
        tags: ["24/7", "Covered", "Shuttle"],
        distance: "25.0",
        updatedAt: new Date(),
      },
      {
        id: "p4",
        name: "Acropolis Parking",
        address: "Near Acropolis Museum, Plaka",
        cityId: "1",
        latitude: "37.9685",
        longitude: "23.7276",
        totalSpots: 90,
        availableSpots: 12,
        pricePerHour: "4.50",
        is24Hours: false,
        isCovered: true,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: false,
        tags: ["Tourist Area", "Covered"],
        distance: "0.25",
        updatedAt: new Date(),
      },
      // Thessaloniki Locations
      {
        id: "p5",
        name: "White Tower Parking",
        address: "Near White Tower, Nikis Avenue",
        cityId: "2",
        latitude: "40.6264",
        longitude: "22.9486",
        totalSpots: 120,
        availableSpots: 5,
        pricePerHour: "2.00",
        is24Hours: true,
        isCovered: false,
        hasSecurityGuard: false,
        isAccessible: true,
        hasEVCharging: true,
        tags: ["Seafront", "Historic"],
        distance: "0.18",
        updatedAt: new Date(),
      },
      {
        id: "p6",
        name: "Aristotelous Square Garage",
        address: "Aristotelous Square Underground",
        cityId: "2",
        latitude: "40.6342",
        longitude: "22.9400",
        totalSpots: 200,
        availableSpots: 18,
        pricePerHour: "1.80",
        is24Hours: true,
        isCovered: true,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: false,
        tags: ["Underground", "City Center"],
        distance: "0.10",
        updatedAt: new Date(),
      },
      // Rhodes Locations
      {
        id: "p7",
        name: "Old Town Parking",
        address: "Near Medieval City, Rhodes",
        cityId: "5",
        latitude: "36.4433",
        longitude: "28.2267",
        totalSpots: 80,
        availableSpots: 15,
        pricePerHour: "3.50",
        is24Hours: false,
        isCovered: false,
        hasSecurityGuard: true,
        isAccessible: false,
        hasEVCharging: false,
        tags: ["Historic", "Tourist Area"],
        distance: "0.08",
        updatedAt: new Date(),
      },
      {
        id: "p8",
        name: "Mandraki Harbor Parking",
        address: "Mandraki Port Area, Rhodes",
        cityId: "5",
        latitude: "36.4503",
        longitude: "28.2275",
        totalSpots: 150,
        availableSpots: 30,
        pricePerHour: "2.80",
        is24Hours: true,
        isCovered: false,
        hasSecurityGuard: false,
        isAccessible: true,
        hasEVCharging: true,
        tags: ["Harbor", "Boats"],
        distance: "0.12",
        updatedAt: new Date(),
      },
      // Mykonos Locations
      {
        id: "p9",
        name: "Mykonos Town Parking",
        address: "Near Windmills, Mykonos",
        cityId: "6",
        latitude: "37.4467",
        longitude: "25.3289",
        totalSpots: 60,
        availableSpots: 3,
        pricePerHour: "5.00",
        is24Hours: false,
        isCovered: false,
        hasSecurityGuard: false,
        isAccessible: false,
        hasEVCharging: false,
        tags: ["Premium", "Limited"],
        distance: "0.05",
        updatedAt: new Date(),
      },
      // Heraklion Locations
      {
        id: "p10",
        name: "Heraklion Port Parking",
        address: "Heraklion Port Authority",
        cityId: "4",
        latitude: "35.3391",
        longitude: "25.1331",
        totalSpots: 200,
        availableSpots: 1,
        pricePerHour: "2.20",
        is24Hours: true,
        isCovered: false,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: true,
        tags: ["Port", "Ferries"],
        distance: "0.20",
        updatedAt: new Date(),
      },
      {
        id: "p11",
        name: "Knossos Palace Parking",
        address: "Near Knossos Archaeological Site",
        cityId: "4",
        latitude: "35.2978",
        longitude: "25.1630",
        totalSpots: 100,
        availableSpots: 2,
        pricePerHour: "3.00",
        is24Hours: false,
        isCovered: false,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: false,
        tags: ["Archaeological", "Tourist"],
        distance: "0.35",
        updatedAt: new Date(),
      },
    ];

    parkingLocations.forEach(location => this.parkingLocations.set(location.id, location));
  }

  async getCities(): Promise<City[]> {
    return Array.from(this.cities.values());
  }

  async getCityById(id: string): Promise<City | undefined> {
    return this.cities.get(id);
  }

  async createCity(insertCity: InsertCity): Promise<City> {
    const id = randomUUID();
    const city: City = { 
      ...insertCity, 
      id,
      imageUrl: insertCity.imageUrl || null,
      totalParkingSpots: insertCity.totalParkingSpots || 0,
      availableSpots: insertCity.availableSpots || 0
    };
    this.cities.set(id, city);
    return city;
  }

  async getParkingLocations(): Promise<ParkingLocation[]> {
    return Array.from(this.parkingLocations.values());
  }

  async getParkingLocationById(id: string): Promise<ParkingLocation | undefined> {
    return this.parkingLocations.get(id);
  }

  async getParkingLocationsByCity(cityId: string): Promise<ParkingLocation[]> {
    return Array.from(this.parkingLocations.values()).filter(
      location => location.cityId === cityId
    );
  }

  async searchParkingLocations(query: string): Promise<ParkingLocation[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.parkingLocations.values()).filter(
      location => 
        location.name.toLowerCase().includes(lowerQuery) ||
        location.address.toLowerCase().includes(lowerQuery)
    );
  }

  async createParkingLocation(insertLocation: InsertParkingLocation): Promise<ParkingLocation> {
    const id = randomUUID();
    const location: ParkingLocation = { 
      ...insertLocation, 
      id,
      is24Hours: insertLocation.is24Hours || false,
      isCovered: insertLocation.isCovered || false,
      hasSecurityGuard: insertLocation.hasSecurityGuard || false,
      isAccessible: insertLocation.isAccessible || false,
      hasEVCharging: insertLocation.hasEVCharging || false,
      tags: insertLocation.tags || null,
      distance: insertLocation.distance || "0",
      updatedAt: new Date()
    };
    this.parkingLocations.set(id, location);
    return location;
  }

  async updateParkingAvailability(id: string, availableSpots: number): Promise<ParkingLocation | undefined> {
    const location = this.parkingLocations.get(id);
    if (location) {
      const updatedLocation = {
        ...location,
        availableSpots,
        updatedAt: new Date()
      };
      this.parkingLocations.set(id, updatedLocation);
      return updatedLocation;
    }
    return undefined;
  }

  async getUserFavorites(userId: string): Promise<UserFavorite[]> {
    return Array.from(this.userFavorites.values()).filter(
      favorite => favorite.userId === userId
    );
  }

  async addUserFavorite(insertFavorite: InsertUserFavorite): Promise<UserFavorite> {
    const id = randomUUID();
    const favorite: UserFavorite = { 
      ...insertFavorite, 
      id,
      createdAt: new Date()
    };
    this.userFavorites.set(id, favorite);
    return favorite;
  }

  async removeUserFavorite(userId: string, parkingLocationId: string): Promise<boolean> {
    const entries = Array.from(this.userFavorites.entries());
    for (const [id, favorite] of entries) {
      if (favorite.userId === userId && favorite.parkingLocationId === parkingLocationId) {
        this.userFavorites.delete(id);
        return true;
      }
    }
    return false;
  }

  async getUserParkingHistory(userId: string): Promise<ParkingHistory[]> {
    return Array.from(this.parkingHistory.values()).filter(
      history => history.userId === userId
    );
  }

  async addParkingHistory(insertHistory: InsertParkingHistory): Promise<ParkingHistory> {
    const id = randomUUID();
    const history: ParkingHistory = { 
      ...insertHistory, 
      id,
      visitedAt: new Date()
    };
    this.parkingHistory.set(id, history);
    return history;
  }
}

export const storage = new MemStorage();

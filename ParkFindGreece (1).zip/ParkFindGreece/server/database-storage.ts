import { 
  cities,
  parkingLocations,
  userFavorites,
  parkingHistory,
  parkingBookings,
  parkingReviews,
  priceAlerts,
  notifications,
  users,
  type City,
  type ParkingLocation,
  type UserFavorite,
  type ParkingHistory,
  type ParkingBooking,
  type ParkingReview,
  type PriceAlert,
  type Notification,
  type User,
  type InsertCity,
  type InsertParkingLocation,
  type InsertUserFavorite,
  type InsertParkingHistory,
  type InsertParkingBooking,
  type InsertParkingReview,
  type InsertPriceAlert,
  type InsertNotification,
  type InsertUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, ilike, sql } from "drizzle-orm";
import type { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  async getCities(): Promise<City[]> {
    return await db.select().from(cities).orderBy(cities.name);
  }

  async getCityById(id: string): Promise<City | undefined> {
    const [city] = await db.select().from(cities).where(eq(cities.id, id));
    return city;
  }

  async createCity(city: InsertCity): Promise<City> {
    const [newCity] = await db.insert(cities).values(city).returning();
    return newCity;
  }

  async getParkingLocations(): Promise<ParkingLocation[]> {
    return await db.select().from(parkingLocations).orderBy(parkingLocations.name);
  }

  async getParkingLocationById(id: string): Promise<ParkingLocation | undefined> {
    const [location] = await db.select().from(parkingLocations).where(eq(parkingLocations.id, id));
    return location;
  }

  async getParkingLocationsByCity(cityId: string): Promise<ParkingLocation[]> {
    return await db.select().from(parkingLocations)
      .where(eq(parkingLocations.cityId, cityId))
      .orderBy(parkingLocations.name);
  }

  async searchParkingLocations(query: string): Promise<ParkingLocation[]> {
    return await db.select().from(parkingLocations)
      .where(
        ilike(parkingLocations.name, `%${query}%`)
      )
      .orderBy(parkingLocations.name);
  }

  async createParkingLocation(location: InsertParkingLocation): Promise<ParkingLocation> {
    const [newLocation] = await db.insert(parkingLocations).values(location).returning();
    return newLocation;
  }

  async updateParkingAvailability(id: string, availableSpots: number): Promise<ParkingLocation | undefined> {
    const [updated] = await db.update(parkingLocations)
      .set({ 
        availableSpots,
        updatedAt: new Date()
      })
      .where(eq(parkingLocations.id, id))
      .returning();
    return updated;
  }

  async getUserFavorites(userId: string): Promise<UserFavorite[]> {
    return await db.select().from(userFavorites)
      .where(eq(userFavorites.userId, userId))
      .orderBy(desc(userFavorites.createdAt));
  }

  async addUserFavorite(favorite: InsertUserFavorite): Promise<UserFavorite> {
    const [newFavorite] = await db.insert(userFavorites).values(favorite).returning();
    return newFavorite;
  }

  async removeUserFavorite(userId: string, parkingLocationId: string): Promise<boolean> {
    const result = await db.delete(userFavorites)
      .where(and(
        eq(userFavorites.userId, userId),
        eq(userFavorites.parkingLocationId, parkingLocationId)
      ));
    return result.rowCount! > 0;
  }

  async getUserParkingHistory(userId: string): Promise<ParkingHistory[]> {
    return await db.select().from(parkingHistory)
      .where(eq(parkingHistory.userId, userId))
      .orderBy(desc(parkingHistory.visitedAt));
  }

  async addParkingHistory(history: InsertParkingHistory): Promise<ParkingHistory> {
    const [newHistory] = await db.insert(parkingHistory).values(history).returning();
    return newHistory;
  }

  // Booking methods
  async getUserBookings(userId: string): Promise<ParkingBooking[]> {
    return await db.select().from(parkingBookings)
      .where(eq(parkingBookings.userId, userId))
      .orderBy(desc(parkingBookings.createdAt));
  }

  async createBooking(booking: InsertParkingBooking): Promise<ParkingBooking> {
    const [newBooking] = await db.insert(parkingBookings).values(booking).returning();
    return newBooking;
  }

  async updateBookingStatus(id: string, status: string): Promise<ParkingBooking | undefined> {
    const [updated] = await db.update(parkingBookings)
      .set({ status })
      .where(eq(parkingBookings.id, id))
      .returning();
    return updated;
  }

  async updateBookingPaymentStatus(id: string, paymentStatus: string): Promise<ParkingBooking | undefined> {
    const [updated] = await db.update(parkingBookings)
      .set({ paymentStatus })
      .where(eq(parkingBookings.id, id))
      .returning();
    return updated;
  }

  // Review methods
  async getLocationReviews(parkingLocationId: string): Promise<ParkingReview[]> {
    return await db.select().from(parkingReviews)
      .where(eq(parkingReviews.parkingLocationId, parkingLocationId))
      .orderBy(desc(parkingReviews.createdAt));
  }

  async createReview(review: InsertParkingReview): Promise<ParkingReview> {
    const [newReview] = await db.insert(parkingReviews).values(review).returning();
    return newReview;
  }

  async getLocationAverageRating(parkingLocationId: string): Promise<number> {
    const [result] = await db.select({
      avgRating: sql<number>`CAST(AVG(${parkingReviews.rating}) AS DECIMAL(3,2))`
    }).from(parkingReviews)
      .where(eq(parkingReviews.parkingLocationId, parkingLocationId));
    return result?.avgRating || 0;
  }

  // Price alert methods
  async getUserPriceAlerts(userId: string): Promise<PriceAlert[]> {
    return await db.select().from(priceAlerts)
      .where(eq(priceAlerts.userId, userId))
      .orderBy(desc(priceAlerts.createdAt));
  }

  async createPriceAlert(alert: InsertPriceAlert): Promise<PriceAlert> {
    const [newAlert] = await db.insert(priceAlerts).values(alert).returning();
    return newAlert;
  }

  async togglePriceAlert(id: string): Promise<PriceAlert | undefined> {
    const [existing] = await db.select().from(priceAlerts).where(eq(priceAlerts.id, id));
    if (!existing) return undefined;

    const [updated] = await db.update(priceAlerts)
      .set({ isActive: !existing.isActive })
      .where(eq(priceAlerts.id, id))
      .returning();
    return updated;
  }

  // Notification methods
  async getUserNotifications(userId: string): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async markNotificationAsRead(id: string): Promise<Notification | undefined> {
    const [updated] = await db.update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return updated;
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db.update(notifications)
      .set({ isRead: true })
      .where(and(
        eq(notifications.userId, userId),
        eq(notifications.isRead, false)
      ));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updated;
  }

  // Initialize with sample data
  async initializeData(): Promise<void> {
    // Check if data already exists
    const existingCities = await this.getCities();
    if (existingCities.length > 0) return;

    // Initialize cities
    const cityData: InsertCity[] = [
      {
        name: "Athens",
        region: "Attica",
        latitude: "37.9838",
        longitude: "23.7275",
        imageUrl: "https://images.unsplash.com/photo-1555993539-1732b0258235?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 2500,
        availableSpots: 142,
      },
      {
        name: "Thessaloniki",
        region: "Central Macedonia",
        latitude: "40.6401",
        longitude: "22.9444",
        imageUrl: "https://images.unsplash.com/photo-1580654712603-eb43273aff33?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 800,
        availableSpots: 23,
      },
      {
        name: "Rhodes",
        region: "South Aegean",
        latitude: "36.4341",
        longitude: "28.2176",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=150",
        totalParkingSpots: 350,
        availableSpots: 45,
      },
    ];

    const createdCities = await Promise.all(cityData.map(city => this.createCity(city)));

    // Initialize parking locations
    const parkingData: InsertParkingLocation[] = [
      {
        name: "Central Athens Parking",
        address: "Syntagma Square, Athens Center",
        cityId: createdCities[0].id,
        latitude: "37.9755",
        longitude: "23.7348",
        totalSpots: 150,
        availableSpots: 24,
        pricePerHour: "2.50",
        is24Hours: true,
        isCovered: true,
        hasSecurityGuard: true,
        isAccessible: true,
        hasEVCharging: false,
        tags: ["24/7", "Covered", "Security"],
        distance: "0.15",
      },
      {
        name: "White Tower Parking",
        address: "Near White Tower, Nikis Avenue",
        cityId: createdCities[1].id,
        latitude: "40.6264",
        longitude: "22.9486",
        totalSpots: 120,
        availableSpots: 5,
        pricePerHour: "2.00",
        is24Hours: true,
        isCovered: false,
        hasSecurityGuard: false,
        isAccessible: true,
        hasEVCharging: true,
        tags: ["Seafront", "Historic"],
        distance: "0.18",
      },
    ];

    await Promise.all(parkingData.map(location => this.createParkingLocation(location)));
  }
}